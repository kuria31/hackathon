package com.sigin_signup.SiginUpPage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiginUpPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiginUpPageApplication.class, args);
	}

}
