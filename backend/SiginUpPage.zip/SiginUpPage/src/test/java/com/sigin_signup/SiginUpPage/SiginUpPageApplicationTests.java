package com.sigin_signup.SiginUpPage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiginUpPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
